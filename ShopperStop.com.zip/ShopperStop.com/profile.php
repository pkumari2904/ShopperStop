<html>
<head>
<title>Profile Page</title>
<style>
.box{
	height:590px;
	width:500px;
	border:2px solid #000;
	border-radius:10px;
	margin-left:320px;
	margin-top:50px;
}

.image{
	height:75px;
	width:75px;
	margin-left:40px;
}

.heading{
	margin-top:-65px;
	
}

.tr1{
	margin-top:20px;
}

.input_box{
	width:250px;
	height:40px;
	border:1px solid #063;
	border-radius: 7px;
	margin-top:15px;
}
.btn	{
	height:30px;
	width:200px;
	background:linear-gradient(#063 45%, #39C 75%);
	border-radius:7px;
	margin-right:-65px;
	font-weight:bold;
}

.btn:hover{
	background:linear-gradient(#39C 45%, #063 75%);
}

.bd	{
	height:1000px;
	width:1060px;
	background:#FFF;
	margin-left:160px;
	margin-top:-15px;
}
.title{
	height:120px;
	background:#090;
	margin-top:-15px;
	border:1px solid #000;
}
.img{
	margin-top:20px;
}
.menu{
	width:1050px;
	height:30px;
	background:#4479BA;
	padding:5px;
}
.link_btn {
   
    border-radius: 4px;
    border: solid 1px #20538D;
    background: #4479BA;
    color: #FFF;
    padding: 8px 12px;
    text-decoration: none;
	margin-top:5px;
}

.lgn_rgstr{
	width:120px;
	height:40px;
	background:linear-gradient(#4479BA 45%, #03C 65%);
	font-weight:bold;
	color:#FFF;
	padding:5px;
	margin-right:-30px;
	margin-top:10px;
}
</style>

</script>
<?php 
require('connect.php');
//$nm = $_POST['user_id'];
//$pas = $_POST['password'];
//$result = mysqli_query($con,"SELECT * FROM users WHERE user_id='" . $nm. "' and password = '". $pas."'");
$result = mysqli_query($con,"SELECT * FROM users WHERE user_id='" . $_SESSION["user_id"] . "'");

$row  = mysqli_fetch_array($result);
if(is_array($row)) {
	$_SESSION["user_id"] = $row['user_id'];
} else {
	$message = "Invalid Username or Password!";
	}

//$_SESSION["user"] = $row['user_id'];
?>
</head>
<body style="background:url(banner.jpg);">
<div class="bd">
	<div class="title">
    	<img class="img" src="title.JPG" /><h3 style="margin-top:-10px; color:#FFF; font-family:'Trebuchet MS', Arial, Helvetica, sans-serif;">Online Store</h3>
    </div>
    <div class="menu"><div style="margin-top:5px;"><a class="link_btn" href="index.php">Home</a><a class="link_btn" href="about.php">About Us</a><a class="link_btn" href="product.php">Show Products</a><a class="link_btn" href="contact.php">Contact Us</a><div style="margin-left:720px;">Welcome <?php echo ucwords($row['name']); ?>, You have successfully logged in!<br>
    </div></div>
    
    
</div>
</div>
<form action="" method="post" id="frmLogout">

Click to <input type="submit" name="logout" value="Logout" class="logout-button">.</div>
</form>
</div>

